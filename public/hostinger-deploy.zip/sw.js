/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-7e5eb42b'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "pwa-maskable-512x512.png",
    "revision": "94d9c90ba553222771782b59cbd86d8d"
  }, {
    "url": "pwa-512x512.png",
    "revision": "f8f3322dc2a4bb9426f861b6ceea56a3"
  }, {
    "url": "pwa-192x192.png",
    "revision": "fbe5577ba899014f9d41ee922c2bb151"
  }, {
    "url": "index.html",
    "revision": "a569a55d7e7d8e61d06d09f19aa5ebb8"
  }, {
    "url": "icon.svg",
    "revision": "08545396211e5d303381da1cdab46a2b"
  }, {
    "url": "icon-maskable-512.png",
    "revision": "94d9c90ba553222771782b59cbd86d8d"
  }, {
    "url": "icon-512.png",
    "revision": "f8f3322dc2a4bb9426f861b6ceea56a3"
  }, {
    "url": "icon-192.png",
    "revision": "fbe5577ba899014f9d41ee922c2bb151"
  }, {
    "url": "favicon.ico",
    "revision": "71ce0155d357009f54e3a4c72f6b3e56"
  }, {
    "url": "favicon-32x32.png",
    "revision": "433c508d00597b06542d9e3b4a173093"
  }, {
    "url": "favicon-16x16.png",
    "revision": "0b5853dabd85c9fe529a1be71a88da82"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "120aef688105a5a9d24b8dbebaf7b346"
  }, {
    "url": "assets/workbox-window.prod.es5-BBnX5xw4.js",
    "revision": null
  }, {
    "url": "assets/index-_bsxd4ow.css",
    "revision": null
  }, {
    "url": "assets/index-C60nj6DI.js",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "120aef688105a5a9d24b8dbebaf7b346"
  }, {
    "url": "favicon-32x32.png",
    "revision": "433c508d00597b06542d9e3b4a173093"
  }, {
    "url": "favicon.ico",
    "revision": "71ce0155d357009f54e3a4c72f6b3e56"
  }, {
    "url": "icon-192.png",
    "revision": "fbe5577ba899014f9d41ee922c2bb151"
  }, {
    "url": "icon-512.png",
    "revision": "f8f3322dc2a4bb9426f861b6ceea56a3"
  }, {
    "url": "icon-maskable-512.png",
    "revision": "94d9c90ba553222771782b59cbd86d8d"
  }, {
    "url": "icon.svg",
    "revision": "08545396211e5d303381da1cdab46a2b"
  }, {
    "url": "manifest.webmanifest",
    "revision": "243603a511ccb405a17544347fb83ad6"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html")));

}));
